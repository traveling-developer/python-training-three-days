# My Package

`poetry-demo` is a simple example Python package that provides a basic function for adding two numbers. This package demonstrates how to structure a Python project and build it using Poetry.

## Installation

To install `poetry-demo`, you can either build it from source or install it directly if it’s available on a repository like PyPI.

### Building and Installing Locally

1. Clone the repository or download the package files.
2. Use Poetry to install dependencies and build the package.

```bash
# Install dependencies
poetry install

# Build the package
poetry build

# Install the package
pip install dist/my_package-0.1.0-py3-none-any.whl
