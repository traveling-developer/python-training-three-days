# __init__.py
from .foo import add_numbers
