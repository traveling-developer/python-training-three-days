
def add_numbers(a, b):
    """Returns the sum of two numbers."""
    return a + b
